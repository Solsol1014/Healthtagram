using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PId : MonoBehaviour
{
    public string pid;
}
